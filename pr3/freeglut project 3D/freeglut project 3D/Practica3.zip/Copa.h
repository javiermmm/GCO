//===========================================
// Javier Martin Moreno-Manzanaro
//===========================================

#ifndef Copa_H_
#define Copa_H_

#include "Malla.h"
 
class Copa : public Malla {
	private:             
		void vertices();
        void caras();              
    public:
		Copa();				
};
#endif
