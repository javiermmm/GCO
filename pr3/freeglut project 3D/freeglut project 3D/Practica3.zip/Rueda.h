//===========================================
// Javier Martin Moreno-Manzanaro
//===========================================

#ifndef Rueda_H_
#define Rueda_H_

#include "ObjetoCompuesto.h"

class Rueda: public ObjetoCompuesto {
	public:
		Rueda();
		~Rueda();
		void dibuja();
};
#endif