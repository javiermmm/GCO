//===========================================
// Javier Martin Moreno-Manzanaro
//===========================================

#include "ObjetoCuadrico.h"

ObjetoCuadrico::ObjetoCuadrico() {}

ObjetoCuadrico::~ObjetoCuadrico() {}