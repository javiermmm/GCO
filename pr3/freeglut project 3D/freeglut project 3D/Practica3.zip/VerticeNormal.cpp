 

#include "VerticeNormal.h"

VerticeNormal::VerticeNormal(int iv, int in) {
	this->iv=iv;
    this->in=in;
}

VerticeNormal::~VerticeNormal() {}

int VerticeNormal::getIV() {
    return iv;
}

int VerticeNormal::getIN() {
    return in;
}

 


